import type { Mock } from 'vitest';

import { vBusdCorePool } from '__mocks__/models/vTokens';

import { restService } from 'utilities';

import { getMarketHistory } from '..';

vi.mock('utilities/restService');

const apiMarketSnapshot = {
  blockNumber: '1',
  blockTimestamp: '1652593258',
  borrowApy: '2.0144969858718893',
  supplyApy: '0.000001537885451792',
  totalBorrowCents: '1000000000',
  totalSupplyCents: '1234567890',
};

describe('getMarketHistory', () => {
  beforeEach(() => {
    (restService as Mock).mockImplementation(async () => ({
      data: { result: { data: [apiMarketSnapshot] } },
    }));
  });

  it('returns market history on success', async () => {
    const response = await getMarketHistory({
      vToken: vBusdCorePool,
      period: 'year',
    });

    expect(response).toEqual({
      marketSnapshots: [
        {
          blockNumber: 1,
          blockTimestamp: 1652593258 * 1000,
          borrowApyPercentage: Number('2.0144969858718893'),
          supplyApyPercentage: Number('0.000001537885451792'),
          totalBorrowCents: Number('1000000000'),
          totalSupplyCents: Number('1234567890'),
        },
      ],
    });
  });

  it('calls correct endpoint', async () => {
    await getMarketHistory({
      vToken: vBusdCorePool,
      period: 'year',
    });

    expect(restService).toHaveBeenCalledTimes(1);
    expect(restService).toHaveBeenCalledWith({
      endpoint: `/markets/history?asset=${vBusdCorePool.address}&period=year`,
      method: 'GET',
    });
  });
});
