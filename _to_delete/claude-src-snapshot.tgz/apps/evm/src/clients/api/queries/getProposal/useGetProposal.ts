import { type QueryObserverOptions, useQuery } from '@tanstack/react-query';

import FunctionKey from 'constants/functionKey';
import { governanceChainId } from 'libs/wallet';
import callOrThrow from 'utilities/callOrThrow';
import { generatePseudoRandomRefetchInterval } from 'utilities/generatePseudoRandomRefetchInterval';
import { type GetProposalInput, type GetProposalOutput, getProposal } from '.';
import { useGetBlockNumber } from '../getBlockNumber/useGetBlockNumber';
import { useGetProposalMinQuorumVotes } from '../getProposalMinQuorumVotes/useGetProposalMinQuorumVotes';
import { useGetCachedProposal } from './useGetCachedProposal';

type TrimmedGetProposalInput = Omit<
  GetProposalInput,
  'currentBlockNumber' | 'proposalMinQuorumVotesMantissa' | 'blockTimeMs' | 'chainId'
>;

type Options = QueryObserverOptions<
  GetProposalOutput,
  Error,
  GetProposalOutput,
  GetProposalOutput,
  [
    FunctionKey.GET_PROPOSAL,
    Omit<GetProposalInput, 'currentBlockNumber' | 'proposalMinQuorumVotesMantissa' | 'blockTimeMs'>,
  ]
>;

const refetchInterval = generatePseudoRandomRefetchInterval('fast');

export const useGetProposal = (input: TrimmedGetProposalInput, options?: Partial<Options>) => {
  const { data: getProposalMinQuorumVotesData } = useGetProposalMinQuorumVotes();
  const proposalMinQuorumVotesMantissa =
    getProposalMinQuorumVotesData?.proposalMinQuorumVotesMantissa;

  const { data: getBlockNumberData } = useGetBlockNumber(
    {
      chainId: governanceChainId,
    },
    {
      refetchInterval,
    },
  );
  const currentBlockNumber = getBlockNumberData?.blockNumber;

  // Initialize proposal using cache if available
  const cachedProposal = useGetCachedProposal({
    proposalId: +input.proposalId,
  });

  return useQuery({
    queryKey: [
      FunctionKey.GET_PROPOSAL,
      {
        ...input,
        chainId: governanceChainId,
      },
    ],
    queryFn: () =>
      callOrThrow(
        {
          currentBlockNumber,
          proposalMinQuorumVotesMantissa,
        },
        params =>
          getProposal({
            ...input,
            ...params,
            chainId: governanceChainId,
          }),
      ),
    refetchInterval,
    initialData: cachedProposal && {
      proposal: cachedProposal,
    },
    refetchOnMount: false,
    ...options,
    enabled:
      typeof currentBlockNumber === 'number' &&
      !!proposalMinQuorumVotesMantissa &&
      (options?.enabled === undefined || options?.enabled),
  });
};
